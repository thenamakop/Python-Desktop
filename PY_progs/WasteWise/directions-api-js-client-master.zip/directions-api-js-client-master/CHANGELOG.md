0.11.1 (2019-01-16)

**Improvements**

- Add more details to error messages ([#47](https://github.com/graphhopper/directions-api-js-client/issues/47) by [karussell](https://github.com/karussell))

0.11 (2018-11-30)

**Improvements**

- Avoid sending local parameters ([#45](https://github.com/graphhopper/directions-api-js-client/issues/45) by [karussell](https://github.com/karussell))

0.10 (2018-07-03)

**API Changes**

- The avoid parameter was changed from `avoid: [ 'motorway', 'toll' ]` to `avoid: 'motorway,toll'` ([#51](https://github.com/graphhopper/geocoder-converter/pull/51) by [Boldtrn](https://github.com/boldtrn)).