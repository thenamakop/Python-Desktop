import React from 'react'

export const Header = () => {
  return (
    <h2><center>
      Expense Tracker Application</center>
    </h2>
  )
}
