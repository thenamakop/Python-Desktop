Release changes in version 2.5.0


- Support for Spring Boot 1.5.20
- New REST api
- Swagger UI supports authentication
- Bug fixing
	- #317
- Vulnerability CVE

