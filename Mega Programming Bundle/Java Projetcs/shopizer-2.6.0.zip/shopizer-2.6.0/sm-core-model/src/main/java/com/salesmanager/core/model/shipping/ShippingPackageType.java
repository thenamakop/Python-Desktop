package com.salesmanager.core.model.shipping;

public enum ShippingPackageType {
	
	ITEM, BOX

}
