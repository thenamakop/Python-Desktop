package com.salesmanager.core.model.order;

public enum OrderSummaryType {
	
	SHOPPINGCART, ORDERTOTAL

}
