package com.salesmanager.core.model.shipping;

public enum ShippingOptionPriceType {
	
	LEAST, HIGHEST, ALL

}
