package com.salesmanager.core.model.catalog.product;

public enum ProductCondition {
	
	NEW, USED

}
