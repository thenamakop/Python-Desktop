package com.salesmanager.core.model.payments;

public enum CreditCardType {
	
	AMEX, VISA, MASTERCARD, DINERS, DISCOVERY

}
