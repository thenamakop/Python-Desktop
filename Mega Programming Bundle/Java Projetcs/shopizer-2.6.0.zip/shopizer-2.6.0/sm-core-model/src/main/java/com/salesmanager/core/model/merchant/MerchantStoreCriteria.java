package com.salesmanager.core.model.merchant;

import com.salesmanager.core.model.common.Criteria;

public class MerchantStoreCriteria extends Criteria {
	
	


}
