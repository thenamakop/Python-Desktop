package com.salesmanager.core.model.order;

public enum OrderValueType {
	
	ONE_TIME, MONTHLY

}
