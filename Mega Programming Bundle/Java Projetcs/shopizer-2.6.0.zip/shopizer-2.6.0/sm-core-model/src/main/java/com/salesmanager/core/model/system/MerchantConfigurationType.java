package com.salesmanager.core.model.system;

public enum MerchantConfigurationType {
	
	INTEGRATION,
	SHOP,
	CONFIG,
	SOCIAL

}
