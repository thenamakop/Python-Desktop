package com.salesmanager.core.model.shipping;

public enum ShippingDescription {

	
	SHORT_DESCRIPTION, LONG_DESCRIPTION
}
