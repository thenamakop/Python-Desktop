package com.salesmanager.core.model.content;

import java.io.Serializable;

public class ImageContentFile extends InputContentFile implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5321162403524229224L;

}
