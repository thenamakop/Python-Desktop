package com.salesmanager.core.business.constants;


public class ShippingConstants {

  public final static String SHIPPING_CONFIGURATION = "SHIPPING_CONFIG";
  public final static String SHIPPING_NATIONAL = "NATIONAL";
  public final static String SHIPPING_INTERNATIONAL = "INTERNATIONAL";

}
