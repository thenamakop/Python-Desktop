FEE_CHARGE_METHOD_CHOICES=(
	('1','Deduct from principal balance'),
	('2', 'Add the fee on top of the loan'),
	)