from django.apps import AppConfig


class LoanConfig(AppConfig):
    name = 'loan'
