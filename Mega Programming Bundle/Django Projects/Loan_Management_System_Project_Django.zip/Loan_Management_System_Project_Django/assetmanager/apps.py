from django.apps import AppConfig


class AssetmanagerConfig(AppConfig):
    name = 'assetmanager'
