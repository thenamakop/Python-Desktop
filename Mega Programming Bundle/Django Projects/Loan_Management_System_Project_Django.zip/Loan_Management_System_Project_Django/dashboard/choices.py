COLOR_CHOICES=(
	('#ff000','red'),
	)

GENDER_CHOICES=(
    ('male','Male'),
    ('female','Female')
	)

RELATIONSHIP_STATUS_CHOICES=(
	('single','Single'),
	('married','Married')
	)

EDUCATIONAL_STATUS_CHOICES=(
    ('Graduate','Graduate'),
    ('High School','High School'),
    ('Phd','Phd'),
    ('Masters','Masters'),
	)

RESIDENTIAL_STATUS_CHOICES=(
    ('Owner', 'Owner'),
    ('Renting','Renting'),
    ('Staying with Parent','Staying with Parent' ),
	)

CURRENCY_CHOICES=(
	('NGN','NGN'),
	('USD','USD')
	)


TITLE_CHOICES = (
    ('MR', 'Mr.'),
    ('MRS', 'Mrs.'),
    ('MS', 'Ms.'),
)

ACCOUNT_CHOICES=(
	('savings','Savings'),
	('current','Current'),
    ('Dollar Account', 'Dollar Account'),
    ('Others','Others'),
	)

PAYMENT_FREQUENCY_CHOICES=(
	('daily','daily'),
	('monthly','monthly'),
	('quaterly','quaterly'),
	('bi-annual','bi-annual'),
    ('yearly','yearly'),
	)

STATUS_CHOICES=(
    ('submitted','submitted'),
    ('in review','in review'),
    ('Open','Open'),
    ('Closed','Closed'),
	)

PAYMENT_METHOD=(
    ('Cash','Cash'),
    ('Bank','Bank'),
	)
MESSAGE_STATUS=(
	('sent','sent'),
	('received','received'),
	)

MARKET_CHOICES=(
	('Enterpreneurs', 'Enterpreneurs'),
	('White Collar Jobs', 'White Collar Jobs'),
	('Students', 'Student'),
	('General', 'General'),
	('Others', 'Others'),
	)

INTEREST_TYPE_CHOICES=(
	 ('Flat Rate','Flat Rate'),
	 ('Reducing Balance', 'Reducing Balance'),
	)