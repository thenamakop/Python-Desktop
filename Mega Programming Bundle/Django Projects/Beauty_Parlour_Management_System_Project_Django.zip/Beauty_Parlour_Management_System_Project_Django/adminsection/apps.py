from django.apps import AppConfig


class AdminsectionConfig(AppConfig):
    name = 'adminsection'
