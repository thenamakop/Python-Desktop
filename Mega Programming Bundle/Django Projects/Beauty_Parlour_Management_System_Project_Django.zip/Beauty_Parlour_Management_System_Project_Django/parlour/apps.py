from django.apps import AppConfig


class ParlourConfig(AppConfig):
    name = 'parlour'
