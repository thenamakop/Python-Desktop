$('.appointment_date').datepicker({
  'format': 'yyyy-m-d',
  'autoclose': true
  });

  $('.appointment_time').timepicker();